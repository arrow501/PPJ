package PPJ7.Task3;

public class Task3 {
    public static void main(String[] args) {
        {
            int wrt = -3;
//            boolean isWrtInRange = true;
//            // set A
//            if (!((wrt > -15 && wrt <= -10) || (wrt > -5 && wrt < 0) || (wrt > 5 && wrt < 10)))
//                isWrtInRange = false;
//            //set B
//            if (!(wrt <= -13 || (wrt > -8 && wrt <= -3)))
//                isWrtInRange = false;
//            // Set C
//            if (!(wrt >= -4))
//                isWrtInRange = false;

            if (wrt == -4 || wrt == -3)
                System.out.println("Number is in all 3 sets");
            else
                System.out.println("Number not in range");
        }
    }
}

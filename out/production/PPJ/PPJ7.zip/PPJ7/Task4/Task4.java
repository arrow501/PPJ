package PPJ7.Task4;

public class Task4 {
    public static void main(String[] args) {
        int a = 2;
        int b = 3;
//        if(!(a<b) && !(a>b))
//        if(a>=b && a<=b)
        if(a==b)
            System.out.println("a");
    }
}

package PPJ7.BonusTask;

public class Bonus {
    public static void main(String[] args) {

    }
}

package PPJ22.Task2;

public class Person {
    private String name;

    public Person(String name){
        this.name = name;
    }
    public String display(){
        return "name:\t" + name +";";
    }

}
package PPJ22.Task3;

public class Pojazd {
    private String color;
    public Pojazd (String color){
        this.color = color;
    }
    public String getColor() {
        return color;
    }
}

package PPJ23.Task6;

public class Pear extends Fruit{
    public Pear(){
        super("Pear");

    }
}

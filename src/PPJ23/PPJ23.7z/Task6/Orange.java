package PPJ23.Task6;

public class Orange extends Fruit {
    public Orange(){
        super("Orange");
    }
}
